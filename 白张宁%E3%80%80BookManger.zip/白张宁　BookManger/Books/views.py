from django.shortcuts import render
from .models import *
# Create your views here.
from django.shortcuts import render,redirect,HttpResponseRedirect
from django.http import JsonResponse

def Books(request):
    books = BooksModle.objects.all()
    return render(request,'books/index.html',books)




