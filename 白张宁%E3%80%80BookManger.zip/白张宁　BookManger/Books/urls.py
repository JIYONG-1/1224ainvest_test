from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^books/$',views.Books),
    # url(r'^list/$',views.list),
    # url(r'^detail/$',views.detail),

    ]