from django.contrib import admin
from .models import *
# Register your models here.
class TypeAdmin(admin.ModelAdmin):
    list_display = ['category']

class BooksAdmin(admin.ModelAdmin):
    list_per_page = 15
    list_display = ['name','author','country','content','click','category']

admin.site.register(BookCategoryModel,TypeAdmin)
admin.site.register(BooksModle,BooksAdmin)

