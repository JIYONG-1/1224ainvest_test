from django.db import models

# Create your models here.

class BookCategoryModel(models.Model):
    category = models.CharField(max_length=30)

    def __str__(self):
        return self.category


class BooksModle(models.Model):
    name = models.CharField(max_length=30)
    author = models.CharField(max_length=30)
    country = models.CharField(max_length=20)
    content = models.TextField()
    click = models.IntegerField()
    category = models.ForeignKey(BookCategoryModel)

    def __str__(self):
        return self.name
